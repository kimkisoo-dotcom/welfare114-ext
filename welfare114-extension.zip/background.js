// Welfare114 확장프로그램 - 백그라운드
// · pcSave*.pdf / pcSave*.hwpx 다운로드가 저장되기 직전에 파일명과 저장 위치를 정한다.
// · 붙임 선택 창에서 고른 파일을 같은 폴더에 저장한다.
// · 문서 정보를 확인하지 못하면 다운로드를 보류하고 알림으로 처리 방법을 묻는다.
// 저장 위치: 다운로드\Welfare114\  (붙임이 있는 문서는 Welfare114\[문서번호] 제목\ 하위 폴더)

const ROOT = "Welfare114";
// 1차 분류: 결재가 끝난 문서(PC저장) / 결재 중 문서(붙임만)
const DONE_DIR = `${ROOT}/결재완료`;
const PENDING_DIR = `${ROOT}/결재중`;
const APP = "Welfare114 확장프로그램";
const ICON = "icons/icon128.png";
const SETTINGS = { fileType: "both", format: "title", dateFmt: "dash", attachPrefix: true, autoOpen: false, custom: [] };
const DATE_FMTS = ["dash", "ydash", "dot", "ydot", "md"];

// ---------- 설정 (구글 계정 동기화) ----------
// 예전 버전에서 이 PC에만 저장해 둔 설정이 있으면 계정 동기화 저장소로 옮긴다.
async function migrateSettings() {
  const keys = Object.keys(SETTINGS);
  const synced = await chrome.storage.sync.get(keys);
  const local = await chrome.storage.local.get(keys);
  const patch = {};
  for (const k of keys) {
    if (synced[k] === undefined) patch[k] = local[k] !== undefined ? local[k] : SETTINGS[k];
  }
  if (Object.keys(patch).length) await chrome.storage.sync.set(patch);
}
// ---------- 그룹웨어 도메인 등록 ----------
// 등록한 도메인(예: welfarew114.org, w114land.org)에서만 기능이 동작한다.
// 우리 기관용 배포본은 preset.json 에 도메인이 들어 있어 설치 즉시 동작한다.
importScripts("domain.js");

async function currentDomain() {
  const { domain } = await chrome.storage.local.get("domain");
  return domain || null;
}

async function ensureDomain() {
  let d = await currentDomain();
  if (d) return d;
  try {
    const p = await (await fetch(chrome.runtime.getURL("preset.json"))).json();
    if (p && p.domain && await chrome.permissions.contains({ origins: [originPattern(p.domain)] })) {
      d = p.domain;
      await chrome.storage.local.set({ domain: d, preset: true });
    }
  } catch (e) { /* 공용 배포본에는 preset.json 이 없음 */ }
  return d;
}

// 등록 도메인에 콘텐츠 스크립트를 연결하고, 여러 파일 자동 다운로드를 허용한다.
async function applyDomain(domain) {
  try {
    const regs = await chrome.scripting.getRegisteredContentScripts();
    if (regs.length) await chrome.scripting.unregisterContentScripts({ ids: regs.map(r => r.id) });
  } catch (e) {}
  if (!domain) return;
  const all = originPattern(domain);
  const viewer = `*://*.${domain}/webhwpctrl/*`;
  await chrome.scripting.registerContentScripts([
    { id: "list", matches: [all], js: ["list.js"], runAt: "document_idle", allFrames: true },
    { id: "detail", matches: [viewer], js: ["detail.js"], runAt: "document_idle" },
    { id: "detailMain", matches: [viewer], js: ["detail-main.js"], runAt: "document_idle", world: "MAIN" },
    { id: "memo", matches: [all], js: ["memo.js"], runAt: "document_idle", allFrames: true }
  ]);
  // 붙임 여러 개를 받을 때 크롬이 묻는 "여러 파일 다운로드 허용"을 이 도메인에 한해 허용
  for (const p of [`http://*.${domain}:*/*`, `https://*.${domain}:*/*`, `*://*.${domain}/*`]) {
    try { await chrome.contentSettings.automaticDownloads.set({ primaryPattern: p, setting: "allow" }); } catch (e) {}
  }
}

async function initDomain(openSetupIfMissing) {
  const d = await ensureDomain();
  await applyDomain(d);
  if (!d && openSetupIfMissing) chrome.tabs.create({ url: "setup.html" });
}

chrome.runtime.onInstalled.addListener(() => {
  migrateSettings().catch(() => {});
  initDomain(true).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  migrateSettings().catch(() => {});
  initDomain(false).catch(() => {});
});

// 초기 설정 화면에서 도메인 등록(권한은 설정 화면에서 사용자가 허용한 뒤 호출)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "setDomain") return;
  (async () => {
    const d = parseDomain(msg.domain);
    if (!d || !(await chrome.permissions.contains({ origins: [originPattern(d)] }))) return sendResponse({ ok: false });
    await chrome.storage.local.set({ domain: d, preset: false });
    await applyDomain(d);
    sendResponse({ ok: true, domain: d });
  })().catch(() => sendResponse({ ok: false }));
  return true;
});

async function settings() {
  const s = { ...SETTINGS, ...(await chrome.storage.sync.get(Object.keys(SETTINGS))) };
  if (!DATE_FMTS.includes(s.dateFmt)) s.dateFmt = "dash";
  return s;
}

// ---------- 파일명 만들기 ----------
// 파일명에는 "/"를 사용할 수 없으므로 슬래시 형식은 마침표로 표기한다.
function fmtDate(iso, f) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  const yy = y.slice(2);
  switch (f) {
    case "ydash": return `${yy}-${m}-${d}`;
    case "dot": return `${y}.${m}.${d}`;
    case "ydot": return `${yy}.${m}.${d}`;
    case "md": {
      const wd = "일월화수목금토"[new Date(Date.UTC(+y, +m - 1, +d)).getUTCDay()];
      return `${m}.${d}(${wd})`;
    }
    default: return `${y}-${m}-${d}`;
  }
}

// 파일·폴더명에 사용할 수 없는 문자를 정리하고, 경로가 지나치게 길어지지 않도록 제한한다.
function sanitize(s, max = 100) {
  return String(s || "")
    .replace(/[\\/:*?"<>|\x00-\x1f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max)
    .replace(/[.\s]+$/, "")
    .trim();
}

// 블록 이어 붙이기: 기본은 공백. 여는 괄호 뒤·닫는 괄호 앞, 구분 기호(_ - .)만 있는 글자 블록 앞뒤는 붙인다.
const SEP_ONLY = /^[_\-.]+$/;
function joinParts(parts) {
  let out = "";
  let prevSep = false;
  for (const p of parts) {
    if (out && !prevSep && !p.sep && !/[\[({]$/.test(out) && !/^[\])}]/.test(p.v)) out += " ";
    out += p.v;
    prevSep = p.sep;
  }
  return out;
}

// 직접 만들기: [{ t: "field", k: "docNo" } | { t: "text", v: "보고서" }, ...]
// 블록 사이에 공백을 넣되, 여는 괄호 뒤·닫는 괄호 앞에는 넣지 않는다.
// 값이 없는 항목은 빼고, 비게 된 괄호쌍은 지운다. 제목이 없으면 맨 뒤에 붙인다.
function customBase(doc, s) {
  const blocks = Array.isArray(s.custom) ? s.custom : [];
  const val = b => {
    if (b.t === "text") return String(b.v || "");
    if (b.k === "date") return doc.date ? fmtDate(doc.date, s.dateFmt) : "";
    return doc[b.k] || "";
  };
  const parts = blocks
    .map(b => ({ v: val(b), sep: b.t === "text" && SEP_ONLY.test(b.v) }))
    .filter(p => p.v !== "");
  if (!blocks.some(b => b.t === "field" && b.k === "title")) parts.push({ v: doc.title, sep: false });
  let out = joinParts(parts);
  out = out.replace(/\[\s*\]|\(\s*\)|\{\s*\}/g, " ");
  return out;
}

function fileBase(doc, s) {
  const no = doc.docNo ? `[${doc.docNo}] ` : "";
  const dt = doc.date ? `[${fmtDate(doc.date, s.dateFmt)}] ` : "";
  let raw;
  switch (s.format) {
    case "doc": raw = no + doc.title; break;
    case "docdate": raw = no + dt + doc.title; break;
    case "date": raw = dt + doc.title; break;
    case "custom": raw = customBase(doc, s); break;
    default: raw = doc.title;
  }
  return sanitize(raw) || "pcSave";
}

// 문서별 폴더명은 제목이 같은 다른 문서와 섞이지 않도록 항상 문서번호를 포함한다.
function folderName(doc) {
  return sanitize(doc.docNo ? `[${doc.docNo}] ${doc.title}` : doc.title) || "pcSave";
}

// ---------- 같은 문서일 때만 덮어쓰기 ----------
// 확장이 저장한 파일마다 "저장 경로 -> 문서" 기록을 남긴다.
// 같은 문서를 다시 저장하면 덮어쓰고, 다른 문서이거나 기록이 없는 파일은 덮어쓰지 않고 번호를 붙인다.
const OWNER_MAX = 3000;

function docId(doc) {
  return doc.docNo || (doc.stepno ? `step:${doc.stepno}` : `title:${doc.title}`);
}

// 크롬이 알려주는 전체 경로나 "Welfare114/폴더/파일.pdf" 를 "welfare114/폴더/파일.pdf" 형태로 통일
function relKey(path) {
  const p = String(path || "").replace(/\\/g, "/");
  const i = p.toLowerCase().lastIndexOf("/" + ROOT.toLowerCase() + "/");
  const rel = i >= 0 ? p.slice(i + 1) : p;
  return rel.toLowerCase();
}

async function conflictFor(path, owner) {
  const { owners = {} } = await chrome.storage.local.get("owners");
  const rec = owners[relKey(path)];
  return rec && rec.doc === owner ? "overwrite" : "uniquify";
}

// 다운로드 id -> 문서 (완료되면 실제 저장 경로로 기록)
async function watchOwner(id, owner) {
  const { ownerJobs = {} } = await chrome.storage.session.get("ownerJobs");
  ownerJobs[id] = owner;
  await chrome.storage.session.set({ ownerJobs });
}

async function recordOwner(id) {
  const { ownerJobs = {} } = await chrome.storage.session.get("ownerJobs");
  const owner = ownerJobs[id];
  if (!owner) return;
  delete ownerJobs[id];
  await chrome.storage.session.set({ ownerJobs });
  const [item] = await chrome.downloads.search({ id });
  if (!item || !item.filename) return;
  const { owners = {} } = await chrome.storage.local.get("owners");
  owners[relKey(item.filename)] = { doc: owner, ts: Date.now() };
  const keys = Object.keys(owners);
  if (keys.length > OWNER_MAX) {
    keys.sort((a, b) => owners[a].ts - owners[b].ts).slice(0, keys.length - OWNER_MAX).forEach(k => delete owners[k]);
  }
  await chrome.storage.local.set({ owners });
}

// ---------- 붙임 다운로드 경로 예약 ----------
// onDeterminingFilename 리스너가 있으면 downloads.download 의 filename 이 무시되므로
// url 별로 경로를 기억해 두었다가 리스너에서 다시 지정한다.
const reserved = new Map();
function reserve(url, path, owner) {
  if (!reserved.has(url)) reserved.set(url, []);
  reserved.get(url).push({ path, owner });
  setTimeout(() => {
    const q = reserved.get(url);
    if (q) { q.shift(); if (!q.length) reserved.delete(url); }
  }, 60 * 1000);
}
function takeReserved(item) {
  for (const u of [item.url, item.finalUrl]) {
    const q = u && reserved.get(u);
    if (q && q.length) {
      const p = q.shift();
      if (!q.length) reserved.delete(u);
      return p;
    }
  }
  return null;
}

// ---------- 문서 정보 미확인 시 보류 처리 ----------
// 같은 PC저장에서 나온 PDF·HWPX는 하나의 알림으로 묶는다.
const held = new Map(); // notificationId -> [{ id, suggest }]
let openHold = null;    // { nid, ts }

// 사용자의 선택을 기다리는 동안 백그라운드가 절전 상태로 들어가지 않도록 유지
let keepAlive = null;
function updateKeepAlive() {
  if (held.size && !keepAlive) {
    keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20 * 1000);
  } else if (!held.size && keepAlive) {
    clearInterval(keepAlive);
    keepAlive = null;
  }
}

function holdUnknown(item, suggest) {
  if (openHold && Date.now() - openHold.ts < 5000 && held.has(openHold.nid)) {
    held.get(openHold.nid).push({ id: item.id, suggest });
    return;
  }
  const nid = `unknown-${item.id}-${Date.now()}`;
  held.set(nid, [{ id: item.id, suggest }]);
  openHold = { nid, ts: Date.now() };
  updateKeepAlive();
  chrome.notifications.create(nid, {
    type: "basic",
    iconUrl: ICON,
    title: `[${APP}] 문서 정보를 확인하지 못했습니다.`,
    message: "파일명을 규칙에 맞게 변경할 수 없습니다. 문서 화면을 새로고침한 후 다시 저장하시기 바랍니다.",
    buttons: [{ title: "원래 이름으로 저장" }, { title: "저장 취소" }],
    requireInteraction: true,
    priority: 2
  });
  // 5분 동안 선택이 없으면 저장을 취소한다.
  setTimeout(() => resolveHold(nid, false), 5 * 60 * 1000);
}

function resolveHold(nid, save) {
  const list = held.get(nid);
  if (!list) return;
  held.delete(nid);
  updateKeepAlive();
  if (openHold && openHold.nid === nid) openHold = null;
  for (const h of list) {
    try { h.suggest(); } catch (e) { /* 이미 처리됨 */ }
    if (!save) {
      chrome.downloads.cancel(h.id).then(() => chrome.downloads.erase({ id: h.id })).catch(() => {});
    }
  }
  chrome.notifications.clear(nid);
}

chrome.notifications.onButtonClicked.addListener((nid, idx) => {
  if (held.has(nid)) resolveHold(nid, idx === 0);
});
chrome.notifications.onClosed.addListener((nid, byUser) => {
  if (byUser && held.has(nid)) resolveHold(nid, false); // 닫으면 저장 취소
});

// ---------- 다운로드 파일명 결정 ----------
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const att = takeReserved(item);
  if (att) {
    (async () => {
      const action = await conflictFor(att.path, att.owner);
      suggest({ filename: att.path, conflictAction: action });
    })().catch(() => suggest({ filename: att.path, conflictAction: "uniquify" }));
    return true;
  }

  const name = (item.filename || "").split(/[\\/]/).pop();
  const m = name.match(/^pcSave\d*\.(pdf|hwpx)$/i);
  if (!m) return; // 그 외 다운로드는 관여하지 않음
  const ext = m[1].toLowerCase();

  (async () => {
    const s = await settings();

    // 선택하지 않은 형식은 저장하지 않음
    if (s.fileType !== "both" && s.fileType !== ext) {
      suggest();
      chrome.downloads.cancel(item.id).then(() => chrome.downloads.erase({ id: item.id })).catch(() => {});
      return;
    }

    // PC저장 클릭 시 기록한 문서 정보가 다운로드보다 늦게 저장될 수 있어 최대 2초 기다린다.
    // 다른 문서의 정보가 잘못 쓰이지 않도록, 클릭 후 30초 안의 기록만 인정한다.
    const fresh = d => d && d.title && Date.now() - d.ts < 30 * 1000;
    let { pendingSave } = await chrome.storage.local.get("pendingSave");
    for (let i = 0; i < 10 && !fresh(pendingSave); i++) {
      await new Promise(r => setTimeout(r, 200));
      ({ pendingSave } = await chrome.storage.local.get("pendingSave"));
    }

    if (!fresh(pendingSave)) { holdUnknown(item, suggest); return; }

    const doc = pendingSave;
    const base = fileBase(doc, s);
    const dir = doc.useFolder ? `${DONE_DIR}/${folderName(doc)}` : DONE_DIR;
    const path = `${dir}/${base}.${ext}`;
    const owner = docId(doc);
    suggest({ filename: path, conflictAction: await conflictFor(path, owner) });
    await watchOwner(item.id, owner);
    await addBody(doc.ts, item.id, !!doc.useFolder);
  })();

  return true; // suggest 를 비동기로 호출함
});

// ---------- 저장 완료 후 폴더 열기 ----------
// 문서별 기록(키 = PC저장 클릭 시각)을 세션 저장소에 둔다. 백그라운드가 잠시 멈춰도 유지된다.
// { ids: [본문 다운로드], doneId, useFolder, pickerDone, openRequested, opened }
async function getRecs() { return (await chrome.storage.session.get("bodies")).bodies || {}; }
async function setRecs(recs) {
  const now = Date.now();
  for (const k of Object.keys(recs)) if (now - +k > 30 * 60 * 1000) delete recs[k]; // 30분 지난 기록 정리
  await chrome.storage.session.set({ bodies: recs });
}

async function addBody(key, id, useFolder) {
  const recs = await getRecs();
  const r = recs[key] || { ids: [], useFolder, pickerDone: !useFolder };
  r.ids.push(id);
  recs[key] = r;
  await setRecs(recs);
}

function showFile(id) {
  try { chrome.downloads.show(id); } catch (e) { chrome.downloads.showDefaultFolder(); }
}

// 열어야 할 조건이 갖춰졌으면 폴더를 연다.
async function maybeOpen(key) {
  const recs = await getRecs();
  const r = recs[key];
  if (!r || r.opened || !r.doneId) return;
  const { autoOpen } = await settings();
  if (r.openRequested || (autoOpen && r.pickerDone)) {
    r.opened = true;
    await setRecs(recs);
    showFile(r.doneId);
  }
}

async function onBodyComplete(id) {
  const recs = await getRecs();
  const key = Object.keys(recs).find(k => recs[k].ids.includes(id));
  if (!key) return;
  const r = recs[key];
  if (!r.doneId) r.doneId = id;
  await setRecs(recs);
  // 문서 화면에 본문 저장 완료를 알림 (붙임이 없는 문서는 이때 안내를 표시)
  await chrome.storage.local.set({ lastSaved: { key: +key, ts: Date.now() } });
  await maybeOpen(key);
}

// 설정 화면의 [Welfare114 폴더 열기]
// 크롬은 파일이 있는 폴더만 열 수 있어서, Welfare114 바로 아래 파일 -> 결재완료/결재중 바로 아래 파일 ->
// Welfare114 안의 가장 최근 파일 순으로 찾아 그 위치를 연다. 저장 기록이 없으면 다운로드 폴더를 연다.
async function openRoot() {
  const items = await chrome.downloads.search({ orderBy: ["-startTime"], limit: 300, exists: true, state: "complete" });
  const pick = re => items.find(i => re.test(i.filename));
  const hit = pick(/[\\/]Welfare114[\\/][^\\/]+$/)
    || pick(/[\\/]Welfare114[\\/](결재완료|결재중)[\\/][^\\/]+$/)
    || pick(/[\\/]Welfare114[\\/]/);
  if (hit) return showFile(hit.id);
  chrome.downloads.showDefaultFolder();
}

// 결재 중 붙임: 본문이 없으므로 첫 붙임 파일로 "폴더 열기"를 처리한다.
async function addPendingFile(key, id) {
  const recs = await getRecs();
  const r = recs[key] || { ids: [], useFolder: true, pickerDone: true };
  r.ids.push(id);
  r.pickerDone = true;
  recs[key] = r;
  await setRecs(recs);
}

// ---------- 붙임파일 저장 + 실패 알림 ----------
const attJobs = new Map(); // downloadId -> { batch, name }
const batches = new Map(); // batchId -> { left, failed: [] }

function finishAttachment(id, ok) {
  const job = attJobs.get(id);
  if (!job) return;
  attJobs.delete(id);
  const b = batches.get(job.batch);
  if (!b) return;
  if (!ok) b.failed.push(job.name);
  if (--b.left > 0) return;
  batches.delete(job.batch);
  if (b.failed.length) notifyAttachmentFail(b.failed);
}

function notifyAttachmentFail(names) {
  const list = names.length > 1 ? `${names[0]} 외 ${names.length - 1}건` : names[0];
  chrome.notifications.create(`attfail-${Date.now()}`, {
    type: "basic",
    iconUrl: ICON,
    title: `[${APP}] 일부 붙임파일을 저장하지 못했습니다.`,
    message: `저장되지 않은 파일: ${list}`,
    priority: 1
  });
}

chrome.downloads.onChanged.addListener(d => {
  if (d.state && d.state.current === "complete") {
    recordOwner(d.id).catch(() => {});
    onBodyComplete(d.id).catch(() => {});
  }
  if (!attJobs.has(d.id) || !d.state) return;
  if (d.state.current === "complete") finishAttachment(d.id, true);
  else if (d.state.current === "interrupted") finishAttachment(d.id, false);
});

chrome.runtime.onMessage.addListener(msg => {
  if (!msg) return;
  if (msg.type === "pickerDone" || msg.type === "openFolder") {
    (async () => {
      const recs = await getRecs();
      const r = recs[msg.key];
      if (!r) return;
      if (msg.type === "pickerDone") r.pickerDone = true;
      else r.openRequested = true;
      await setRecs(recs);
      await maybeOpen(String(msg.key));
    })().catch(() => {});
    return;
  }
  if (msg.type === "openRoot") { openRoot().catch(() => chrome.downloads.showDefaultFolder()); return; }
});

chrome.runtime.onMessage.addListener(msg => {
  if (!msg || msg.type !== "downloadAttachments" || !msg.doc || !Array.isArray(msg.items)) return;
  (async () => {
    // 결재 중 문서는 문서번호가 없으므로 Welfare114\결재중\제목\ 에 저장한다.
    const pending = msg.stage === "pending";
    const dir = pending
      ? `${PENDING_DIR}/${sanitize(msg.doc.title) || "붙임"}`
      : `${DONE_DIR}/${folderName(msg.doc)}`;
    const batch = `${Date.now()}-${Math.random()}`;
    const b = { left: 1, failed: [] }; // 1 = 목록 처리 중 표시 (끝나면 해제)
    batches.set(batch, b);
    for (const it of msg.items) {
      let url;
      try { url = new URL(it.url); } catch (e) { b.failed.push(it.name); continue; }
      const d = await currentDomain(); // 등록한 그룹웨어 도메인의 링크만 허용
      if (!d || !(url.hostname === d || url.hostname.endsWith("." + d))) continue;
      const label = msg.prefix && it.no ? `[첨부 ${it.no}] ${it.name}` : it.name;
      const path = `${dir}/${sanitize(label, 150) || "붙임"}`;
      const owner = docId(msg.doc);
      reserve(url.href, path, owner);
      b.left++;
      try {
        const id = await chrome.downloads.download({ url: url.href, filename: path, conflictAction: "uniquify", saveAs: false });
        attJobs.set(id, { batch, name: it.name });
        await watchOwner(id, owner);
        if (pending) await addPendingFile(msg.doc.ts, id); // [폴더 열기]·자동 열기용
        // 등록 전에 이미 끝난 다운로드도 반영
        const [cur] = await chrome.downloads.search({ id });
        if (cur && cur.state === "complete") {
          finishAttachment(id, true);
          if (pending) { recordOwner(id).catch(() => {}); onBodyComplete(id).catch(() => {}); }
        }
        else if (cur && cur.state === "interrupted") finishAttachment(id, false);
      } catch (e) {
        b.left--;
        b.failed.push(it.name);
      }
    }
    if (--b.left === 0) {
      batches.delete(batch);
      if (b.failed.length) notifyAttachmentFail(b.failed);
    }
  })();
});
