// 상세 창(페이지 쪽): 한글 뷰어에서 "시행일자" 필드를 읽어 data 속성으로 넘긴다.
// 목록에서 기안일자를 못 가져왔을 때의 대체값으로만 쓴다.
(function () {
  let n = 0;
  const t = setInterval(() => {
    n++;
    try {
      const H = window.pHwpCtrl;
      if (H && typeof H.GetFieldText === "function") {
        document.documentElement.dataset.pcsaveSihaeng = H.GetFieldText("시행일자") || "";
        clearInterval(t);
      }
    } catch (e) { /* 뷰어 로딩 중 */ }
    if (n > 60) clearInterval(t);
  }, 500);
})();
