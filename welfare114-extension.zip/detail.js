// 상세 창: 숨겨진 "문서정보"(#docview)에서 문서번호·제목·붙임파일을 읽고,
// 기안일자는 목록에서 기억해 둔 값(hidStepno로 연결) -> 없으면 한글 본문 시행일자 순으로 찾는다.
// PC저장 버튼을 누르면 그 순간의 문서 정보를 pendingSave 로 저장하고,
// 붙임이 있으면 고를 수 있는 선택 창을 띄운다.
(function () {
  "use strict";

  // 확장을 새로고침하면 이미 열린 화면의 스크립트는 확장과 연결이 끊긴다.
  // 그 상태에서는 아무것도 하지 않아 "Extension context invalidated" 오류를 막는다.
  const alive = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };
  const safe = fn => { if (!alive()) return; try { const r = fn(); if (r && r.catch) r.catch(() => {}); } catch (e) {} };

  // 문서정보 라벨(공백 제거) -> 저장 항목
  const LABELS = {
    docNo: "문서번호", title: "제목", dept: "부서(팀)명", writer: "작성자",
    position: "직위", keep: "보존기간", open: "공개등급", category: "문서분류(2)"
  };

  function readDocview() {
    const dv = document.getElementById("docview");
    if (!dv) return null;
    const out = {};
    dv.querySelectorAll("td").forEach(td => {
      const lab = td.textContent.replace(/\s+/g, "");
      for (const [k, l] of Object.entries(LABELS)) {
        if (lab !== l || out[k]) continue;
        const el = td.nextElementSibling && td.nextElementSibling.querySelector("input,textarea,select");
        if (!el) continue;
        // 선택 목록(문서분류 등)은 선택된 항목의 글자, "▒선택▒" 같은 빈 선택은 제외
        const v = el.tagName === "SELECT"
          ? (el.selectedOptions[0] ? el.selectedOptions[0].text : "")
          : el.value;
        const t = (v || "").trim();
        if (t && !/▒|^선택$/.test(t)) out[k] = t;
      }
    });
    return out.title ? out : null;
  }

  // 문서정보의 "첨부#1~#10" 칸에 있는 다운로드 링크
  function readAttachments() {
    const dv = document.getElementById("docview");
    if (!dv) return [];
    return [...dv.querySelectorAll('a[href*="download23.jsp"]')]
      .map(a => {
        // 그룹웨어의 "첨부#N" 번호
        const row = a.closest("tr");
        const m = row && row.cells[0] && row.cells[0].textContent.match(/첨부\s*#?\s*(\d+)/);
        return {
          no: m ? +m[1] : null,
          name: a.textContent.trim(),
          url: new URL(a.getAttribute("href"), location.href).href
        };
      })
      .filter(x => x.name);
  }

  function isoFrom(text) {
    const m = String(text || "").match(/(\d{4})\D+(\d{1,2})\D+(\d{1,2})/);
    if (!m) return "";
    return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  }

  const stepno = new URL(location.href).searchParams.get("hidStepno") || "";

  async function collect() {
    const info = readDocview();
    if (!info) return null;
    let date = "";
    if (stepno) {
      const { recent = [] } = await chrome.storage.local.get("recent");
      const hit = [...recent].reverse().find(r => r.nums.includes(stepno));
      if (hit) date = hit.date;
    }
    if (!date) date = isoFrom(document.documentElement.dataset.pcsaveSihaeng);
    return { ...info, date, stepno, useFolder: false, ts: Date.now() };
  }

  // PC저장 버튼 바로 아래, 버튼 가운데에 맞춰 표시할 위치 (화면 밖으로 나가지 않게)
  function placeUnder(anchor, W) {
    const r = anchor ? anchor.getBoundingClientRect() : { left: innerWidth - W - 16, width: W, bottom: 16 };
    const left = Math.max(8, Math.min(innerWidth - W - 8, r.left + r.width / 2 - W / 2));
    const arrowX = Math.max(16, Math.min(W - 16, r.left + r.width / 2 - left));
    return { top: Math.round(r.bottom + 10), left: Math.round(left), arrowX };
  }

  // ---------- 저장 완료 안내 ----------
  function showNotice(anchor, key) {
    document.getElementById("pcsave-notice-host")?.remove();
    const W = 300;
    const p = placeUnder(anchor, W);
    const host = document.createElement("div");
    host.id = "pcsave-notice-host";
    host.style.cssText = `position:fixed;top:${p.top}px;left:${p.left}px;z-index:2147483647;`;
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        .box { position: relative; width: ${W}px; background: #fff; border: 1px solid #9fb3d1; border-radius: 10px;
               box-shadow: 0 6px 20px rgba(0,0,0,.22); font: 13px/1.5 "Malgun Gothic", sans-serif; color: #222; }
        .box::before { content: ""; position: absolute; top: -7px; left: ${p.arrowX - 7}px; width: 12px; height: 12px;
               background: #fff; border-left: 1px solid #9fb3d1; border-top: 1px solid #9fb3d1; transform: rotate(45deg); }
        .msg { padding: 12px 14px 8px; font-weight: bold; }
        .msg .ok { color: #2f855a; margin-right: 4px; }
        .ft { display: flex; justify-content: space-between; gap: 8px; padding: 0 14px 12px; }
        button { font: inherit; border: 1px solid #c9d3e3; background: #fff; border-radius: 6px; padding: 5px 12px; cursor: pointer; }
        button.open { background: #2b6cb0; color: #fff; border-color: #2b6cb0; font-weight: bold; }
      </style>
      <div class="box">
        <div class="msg"><span class="ok">✔</span>저장이 완료되었습니다.</div>
        <div class="ft"><button class="open">폴더 열기</button><button class="close">닫기</button></div>
      </div>`;
    const close = () => host.remove();
    root.querySelector(".open").addEventListener("click", () => {
      safe(() => chrome.runtime.sendMessage({ type: "openFolder", key }));
      close();
    });
    root.querySelector(".close").addEventListener("click", close);
    setTimeout(close, 10 * 1000); // 10초 후 자동으로 닫힘
    document.documentElement.appendChild(host);
  }

  // 자동 열기가 꺼져 있을 때만 완료 안내를 표시
  async function afterSave(anchor, key) {
    if (!alive()) return;
    const { autoOpen = false } = await chrome.storage.sync.get("autoOpen");
    if (!autoOpen) showNotice(anchor, key);
  }

  // 본문 저장이 끝날 때까지 기다린다 (백그라운드가 lastSaved 로 알려줌, 최대 60초)
  function waitBodySaved(key) {
    return new Promise(resolve => {
      const done = ok => { chrome.storage.onChanged.removeListener(onChg); clearTimeout(t); resolve(ok); };
      const onChg = (ch, area) => {
        if (area === "local" && ch.lastSaved && ch.lastSaved.newValue && ch.lastSaved.newValue.key === key) done(true);
      };
      chrome.storage.onChanged.addListener(onChg);
      const t = setTimeout(() => done(false), 60 * 1000);
    });
  }

  // ---------- 붙임 선택 창 ----------
  // pending: 결재 중 문서(본문 없이 붙임만 저장 -> Welfare114결재중제목)
  function showPicker(doc, atts, anchor, prefixOn, autoOpen, pending) {
    document.getElementById("pcsave-attach-host")?.remove();
    const W = 380;
    const host = document.createElement("div");
    host.id = "pcsave-attach-host";
    // PC저장 버튼 바로 아래, 버튼 가운데에 맞춰 표시 (화면 밖으로 나가지 않게)
    const { top, left, arrowX } = placeUnder(anchor, W);
    host.style.cssText = `position:fixed;top:${top}px;left:${left}px;z-index:2147483647;`;
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        .box { position: relative; width: ${W}px; background: #fff; border: 1px solid #9fb3d1; border-radius: 10px;
               box-shadow: 0 6px 20px rgba(0,0,0,.22); font: 13px/1.5 "Malgun Gothic", sans-serif; color: #222; }
        .box::before { content: ""; position: absolute; top: -7px; left: ${arrowX - 7}px; width: 12px; height: 12px;
               background: #f3f7fc; border-left: 1px solid #9fb3d1; border-top: 1px solid #9fb3d1; transform: rotate(45deg); }
        .hd { display: flex; justify-content: space-between; align-items: center; padding: 10px 14px;
              background: #f3f7fc; border-bottom: 1px solid #e1e8f2; border-radius: 10px 10px 0 0; font-weight: bold; font-size: 14px; }
        .x { cursor: pointer; color: #888; font-size: 18px; line-height: 1; border: 0; background: none; padding: 0 2px; }
        .list { max-height: 240px; overflow: auto; padding: 4px 14px; }
        .item { display: flex; gap: 8px; align-items: flex-start; padding: 7px 0; cursor: pointer; word-break: break-all;
                border-bottom: 1px dashed #edf0f5; }
        .item:last-child { border-bottom: 0; }
        .no { flex: none; min-width: 20px; height: 20px; padding: 0 4px; box-sizing: border-box; border-radius: 10px;
              background: #2b6cb0; color: #fff; font-size: 11px; font-weight: bold; text-align: center; line-height: 20px; }
        input { margin-top: 3px; width: 15px; height: 15px; flex: none; }
        .optsec { border-top: 2px solid #c9d6ea; background: #f6f8fb; padding: 8px 14px 10px; }
        .optttl { font-size: 11px; font-weight: bold; color: #6b7a90; margin-bottom: 4px; }
        .opt { display: flex; gap: 8px; align-items: flex-start; cursor: pointer; }
        .opt .ex { display: block; font-size: 11px; color: #888; }
        .ft { display: flex; align-items: center; gap: 6px; padding: 10px 14px; border-top: 1px solid #e1e8f2; }
        .ft .sp { flex: 1; }
        button.b { font: inherit; font-size: 12px; border: 1px solid #c9d3e3; background: #fff; border-radius: 6px; padding: 5px 9px; cursor: pointer; white-space: nowrap; }
        button.skip { color: #2b6cb0; border-color: #9fb3d1; }
        button.go { background: #2b6cb0; color: #fff; border-color: #2b6cb0; font-weight: bold; }
        button.go:disabled { opacity: .5; cursor: default; }
      </style>
      <div class="box">
        <div class="hd"><span>${pending ? "붙임파일 저장" : "붙임파일 함께 저장"}</span><button class="x" title="붙임파일을 저장하지 않고 닫기">✕</button></div>
        <div class="list">
          ${atts.map((a, i) => `<label class="item"><span class="no"></span><input type="checkbox" data-i="${i}" checked><span class="nm"></span></label>`).join("")}
        </div>
        <div class="optsec">
          <div class="optttl">저장 옵션</div>
          <label class="opt"><input type="checkbox" class="prefix"${prefixOn ? " checked" : ""}>
            <span>파일명 앞에 첨부 번호 표기<span class="ex">예: [첨부 1] 붙임파일.pdf</span></span></label>
        </div>
        <div class="ft">
          <button class="b all">전체 해제</button>
          <span class="sp"></span>
          ${autoOpen || pending ? "" : `<button class="b skip">저장하지 않고 폴더 열기</button>`}
          <button class="b go">선택 파일 저장</button>
        </div>
      </div>`;
    // 번호와 파일 이름은 textContent 로 넣어 HTML 해석을 막는다
    root.querySelectorAll(".item").forEach((it, i) => {
      it.querySelector(".no").textContent = atts[i].no != null ? atts[i].no : i + 1;
      it.querySelector(".nm").textContent = atts[i].name;
    });

    const boxes = [...root.querySelectorAll(".list input[type=checkbox]")];
    const go = root.querySelector(".go");
    const prefix = root.querySelector(".prefix");
    const allBtn = root.querySelector(".all");
    const refresh = () => {
      go.disabled = !boxes.some(b => b.checked);
      allBtn.textContent = boxes.every(b => b.checked) ? "전체 해제" : "전체 선택";
    };
    boxes.forEach(b => b.addEventListener("change", refresh));
    allBtn.addEventListener("click", () => {
      const on = !boxes.every(b => b.checked);
      boxes.forEach(b => (b.checked = on));
      refresh();
    });
    // 첨부 번호 옵션은 마지막으로 고른 상태를 기억
    prefix.addEventListener("change", () => safe(() => chrome.storage.sync.set({ attachPrefix: prefix.checked })));
    const finish = () => {
      host.remove();
      safe(() => chrome.runtime.sendMessage({ type: "pickerDone", key: doc.ts }));
      afterSave(anchor, doc.ts).catch(() => {});
    };
    // 결재 중 문서는 저장한 것이 없으므로 닫기만 한다
    root.querySelector(".x").addEventListener("click", () => (pending ? host.remove() : finish()));
    // 붙임은 저장하지 않고 본문이 저장된 폴더를 바로 연다 (완료 안내는 표시하지 않음)
    root.querySelector(".skip")?.addEventListener("click", () => {
      host.remove();
      safe(() => chrome.runtime.sendMessage({ type: "pickerDone", key: doc.ts }));
      safe(() => chrome.runtime.sendMessage({ type: "openFolder", key: doc.ts }));
    });
    go.addEventListener("click", () => {
      const items = boxes.filter(b => b.checked).map(b => atts[+b.dataset.i]);
      safe(() => chrome.runtime.sendMessage({ type: "downloadAttachments", doc, items, prefix: prefix.checked, stage: pending ? "pending" : "done" }));
      finish();
    });
    document.documentElement.appendChild(host);
  }

  // PC저장 클릭 순간의 문서 정보 (여러 문서 창을 열어둬도 정확하게)
  document.addEventListener("click", async e => {
    if (!alive()) return;
    if (!e.target.closest) return;
    // PC저장 버튼은 기능 이름(FilesavepPC)으로 인식하고, 버튼 문구는 보조로 확인한다.
    let el = e.target.closest('[onclick*="FilesavepPC"]');
    if (!el) {
      const c = e.target.closest("a,img,button,input,span,div,td");
      const label = c ? [c.getAttribute("alt"), c.getAttribute("title"), c.value, c.textContent]
        .filter(Boolean).join(" ").replace(/\s+/g, "") : "";
      if (c && /PC저장/i.test(label) && label.length <= 20) el = c;
    }
    if (!el) return;

    try {
      // 클릭 직후 다운로드가 시작되므로 pendingSave 를 먼저 빠르게 기록한다
      const doc = await collect();
      if (!doc) return;
      const atts = readAttachments();
      doc.useFolder = atts.length > 0; // 붙임이 있으면 항상 하위 폴더 + 선택 창
      await chrome.storage.local.set({ pendingSave: doc });
      if (doc.useFolder) {
        const { attachPrefix = true, autoOpen = false } = await chrome.storage.sync.get(["attachPrefix", "autoOpen"]);
        showPicker(doc, atts, el, attachPrefix, autoOpen);
      } else if (await waitBodySaved(doc.ts)) {
        await afterSave(el, doc.ts);
      }
    } catch (err) { /* 확장이 새로고침되어 연결이 끊긴 경우 조용히 무시 */ }
  }, true);

  // ---------- 결재 중 문서: [붙임 저장] 버튼 ----------
  // 결재 버튼(fn_nextstep)이 있고 PC저장 버튼이 없는 화면을 결재 중 문서로 본다.
  function showPendingButton() {
    if (document.getElementById("pcsave-pending-host")) return;
    if (!document.querySelector('[onclick*="fn_nextstep"]') || document.querySelector('[onclick*="FilesavepPC"]')) return;
    const atts = readAttachments();
    if (!atts.length || !readDocview()) return;

    const host = document.createElement("div");
    host.id = "pcsave-pending-host";
    host.style.cssText = "position:fixed;top:12px;right:20px;z-index:2147483646;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
      <style>
        button { font: bold 13px/1 "Malgun Gothic", sans-serif; color: #fff; background: #2b6cb0; border: 0; border-radius: 18px;
                 padding: 9px 16px; cursor: pointer; box-shadow: 0 3px 10px rgba(0,0,0,.25); }
        button:hover { background: #245a93; }
      </style>
      <button title="결재 중 문서의 붙임파일을 저장합니다"></button>`;
    const btn = root.querySelector("button");
    btn.textContent = `📎 붙임 저장 (${atts.length})`;
    btn.addEventListener("click", async () => {
      if (!alive()) return;
      try {
        const doc = await collect();
        if (!doc) return;
        doc.useFolder = true;
        const { attachPrefix = true, autoOpen = false } = await chrome.storage.sync.get(["attachPrefix", "autoOpen"]);
        showPicker(doc, readAttachments(), btn, attachPrefix, autoOpen, true);
      } catch (err) { /* 연결 끊김 무시 */ }
    });
    document.documentElement.appendChild(host);
  }

  // 문서정보가 그려질 때까지 잠시 기다렸다가 버튼 표시
  let pendTries = 0;
  const pendTimer = setInterval(() => {
    pendTries++;
    if (!alive() || document.getElementById("pcsave-pending-host") || pendTries > 30) { clearInterval(pendTimer); return; }
    showPendingButton();
  }, 500);
})();
