// 목록 화면: "확인" 버튼을 누르는 순간 그 행의 기안일자와 고유번호들을 기억한다.
// 상세 창 주소의 hidStepno 가 여기 기억한 번호 중 하나와 일치하면 그 기안일자를 쓴다.
(function () {
  "use strict";

  // 확장을 새로고침하면 이미 열린 화면의 스크립트는 확장과 연결이 끊긴다 -> 조용히 무시
  const alive = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };

  function headerIndex(table, label) {
    if (!table) return -1;
    for (const r of [...table.rows].slice(0, 5)) {
      const i = [...r.cells].findIndex(c => c.textContent.replace(/\s+/g, "") === label);
      if (i >= 0) return i;
    }
    return -1;
  }

  document.addEventListener("click", async e => {
    if (!alive()) return;
    const btn = e.target.closest && e.target.closest('[onclick*="fn_pagego"]');
    if (!btn) return;
    const tr = btn.closest("tr");
    if (!tr) return;

    let text = "";
    const idx = headerIndex(tr.closest("table"), "기안일자");
    if (idx >= 0 && tr.cells[idx]) text = tr.cells[idx].textContent;
    if (!/\d{4}-\d{2}-\d{2}/.test(text)) {
      const cell = [...tr.cells].find(c => /^\s*\d{4}-\d{2}-\d{2}/.test(c.textContent));
      text = cell ? cell.textContent : "";
    }
    const m = text.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return;

    const nums = (btn.getAttribute("onclick") || "").match(/\d{3,}/g) || [];
    const rec = { nums, date: `${m[1]}-${m[2]}-${m[3]}`, ts: Date.now() };
    try {
      const s = await chrome.storage.local.get("recent");
      const week = 7 * 24 * 3600 * 1000;
      const recent = (s.recent || []).filter(x => Date.now() - x.ts < week).slice(-199);
      recent.push(rec);
      await chrome.storage.local.set({ recent });
    } catch (err) { /* 연결 끊김 등은 무시 */ }
  }, true);
})();
