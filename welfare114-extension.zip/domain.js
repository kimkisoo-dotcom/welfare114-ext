// 그룹웨어 주소에서 등록할 도메인을 뽑는다.
// 어떤 화면 주소를 넣어도 경로·쿼리는 무시하고 도메인만 사용한다.
//   https://knwc0051.welfarew114.org/service/xxx.jsp?id=m1  ->  welfarew114.org
//   hello-senior.w114land.org                              ->  w114land.org
//   abc.example.co.kr                                      ->  example.co.kr
const KR_2ND = ["co", "or", "go", "ac", "ne", "re", "pe", "hs", "ms", "es", "sc", "kg", "mil"];

function parseDomain(input) {
  let s = String(input || "").trim();
  if (!s) return null;
  if (!/^[a-z]+:\/\//i.test(s)) s = "https://" + s;
  let host;
  try { host = new URL(s).hostname.toLowerCase(); } catch (e) { return null; }
  if (!host || /^\d+\.\d+\.\d+\.\d+$/.test(host) || !host.includes(".")) return null;
  const parts = host.split(".").filter(Boolean);
  if (parts.length < 2) return null;
  const twoLevel = parts.length >= 3 && parts[parts.length - 1] === "kr" && KR_2ND.includes(parts[parts.length - 2]);
  return parts.slice(twoLevel ? -3 : -2).join(".");
}

// 등록 도메인 -> 크롬 권한/콘텐츠 스크립트 주소 형식
function originPattern(domain) {
  return `*://*.${domain}/*`;
}
