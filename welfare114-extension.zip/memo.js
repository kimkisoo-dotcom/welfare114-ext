// 조치사항 자동 입력
// 설정한 단축키(기본 Alt+Q)를 누르면 커서 위치에 "오늘 날짜 + 이름"을 설정한 형식으로 입력한다.
// 커서가 입력칸에 없으면 화면의 "조치사항" 칸을 찾아 맨 뒤에 붙인다. 결재 버튼은 누르지 않는다.
(function () {
  "use strict";

  const alive = () => { try { return !!chrome.runtime?.id; } catch (e) { return false; } };
  const DEFAULT_KEY = { alt: true, ctrl: false, shift: false, code: "KeyQ" };

  let conf = { memoOn: false, memoName: "", memoFmt: "md_name", memoKey: DEFAULT_KEY };
  function load() {
    if (!alive()) return;
    chrome.storage.sync.get(["memoOn", "memoName", "memoFmt", "memoKey"]).then(s => {
      conf = {
        memoOn: !!s.memoOn,
        memoName: (s.memoName || "").trim(),
        memoFmt: s.memoFmt || "md_name",
        memoKey: s.memoKey && s.memoKey.code ? s.memoKey : DEFAULT_KEY
      };
    }).catch(() => {});
  }
  load();
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "sync" && (ch.memoOn || ch.memoName || ch.memoFmt || ch.memoKey)) load();
    });
  } catch (e) { /* 연결 끊김 */ }

  function stamp() {
    const d = new Date();
    const m = d.getMonth() + 1, day = d.getDate();
    const n = conf.memoName;
    if (conf.memoFmt === "name_md") return `${n}(${m}/${day})`;
    if (conf.memoFmt === "name_dot") return `${n}(${m}.${day}.)`;
    return `${m}/${day} ${n}`;
  }

  // 앞 내용이 쉼표·공백·마침표로 끝나면 공백만, 그 외에는 쉼표+공백을 붙인다.
  function joiner(before) {
    if (!before.trim()) return "";
    if (/\s$/.test(before)) return "";
    if (/[,.]$/.test(before)) return " ";
    return ", ";
  }

  // 화면에 보이는 칸만 대상으로 한다 (한글 뷰어 내부의 숨은 입력칸 등 제외)
  // anywhere: 화면 밖(스크롤 아래)에 있어도 표시된 칸이면 인정 (조치사항 칸 찾기용)
  function isVisible(el, anywhere) {
    if (!el.getClientRects().length) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) return false;
    if (anywhere) return r.right > 0 && r.left < innerWidth; // 가로로 화면 밖에 숨긴 칸은 제외
    return r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight;
  }

  function isTextField(el, anywhere) {
    if (!el || !isVisible(el, anywhere)) return false;
    if (el.isContentEditable) return true;
    if (el.tagName === "TEXTAREA") return !el.readOnly && !el.disabled;
    if (el.tagName === "INPUT") {
      const t = (el.getAttribute("type") || "text").toLowerCase();
      return ["text", "search", ""].includes(t) && !el.readOnly && !el.disabled;
    }
    return false;
  }

  // 화면의 "조치사항" 칸 찾기 (라벨 칸 옆의 입력칸)
  function findMemoField() {
    for (const td of document.querySelectorAll("td,th,label,span")) {
      const lab = td.textContent.replace(/\s+/g, "");
      if (!/^조치사항/.test(lab) || lab.length > 12) continue;
      const box = td.nextElementSibling;
      const el = box && box.querySelector("textarea,input[type=text],input:not([type])");
      if (isTextField(el, true)) return el;
    }
    return null;
  }

  // atEnd: 커서가 그 칸에 없을 때(조치사항 칸을 찾아 넣는 경우) 맨 뒤에 붙인다.
  function insertInto(el, text, atEnd) {
    if (el.isContentEditable) {
      el.focus();
      const sel = window.getSelection();
      const before = sel && sel.anchorNode ? (sel.anchorNode.textContent || "").slice(0, sel.anchorOffset) : "";
      document.execCommand("insertText", false, joiner(before) + text);
      return;
    }
    const len = el.value.length;
    const start = atEnd ? len : (el.selectionStart ?? len);
    const end = atEnd ? len : (el.selectionEnd ?? len);
    const after = el.value.slice(end);
    const ins = joiner(el.value.slice(0, start)) + text + (after && !/^[\s,]/.test(after) ? " " : "");
    el.focus();
    el.setRangeText(ins, start, end, "end");
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function toast(msg) {
    document.getElementById("w114-memo-toast")?.remove();
    const host = document.createElement("div");
    host.id = "w114-memo-toast";
    host.style.cssText = "position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
      .t { background: #2d3748; color: #fff; font: 13px/1.5 "Malgun Gothic", sans-serif; padding: 8px 14px;
           border-radius: 8px; box-shadow: 0 4px 14px rgba(0,0,0,.25); }</style><div class="t"></div>`;
    root.querySelector(".t").textContent = msg;
    document.documentElement.appendChild(host);
    setTimeout(() => host.remove(), 2500);
  }

  function matches(e, k) {
    return e.code === k.code && !!e.altKey === !!k.alt && !!e.ctrlKey === !!k.ctrl && !!e.shiftKey === !!k.shift && !e.metaKey;
  }

  document.addEventListener("keydown", e => {
    if (!alive() || !conf.memoOn || e.repeat || !matches(e, conf.memoKey)) return; // 사용 설정 시에만 동작
    e.preventDefault();
    e.stopPropagation();
    if (!conf.memoName) {
      toast("[Welfare114 확장프로그램] 설정 화면의 '조치사항 자동 입력'에서 이름을 먼저 입력하시기 바랍니다.");
      return;
    }
    const focused = isTextField(document.activeElement) ? document.activeElement : null;
    const target = focused || findMemoField();
    if (target) {
      if (!focused) target.scrollIntoView({ block: "center" });
      insertInto(target, stamp(), !focused);
      return;
    }

    // 결재 화면: 조치사항 칸은 숨겨진 '문서정보' 안에 있으므로, 닫혀 있으면 펼친 뒤 입력한다.
    const dv = document.getElementById("docview");
    const infoBtn = document.querySelector('[onclick^="docPreview"]');
    if (dv && getComputedStyle(dv).display === "none") {
      if (infoBtn) infoBtn.click(); else dv.style.display = "block";
      setTimeout(() => {
        const t = findMemoField();
        if (t) { t.scrollIntoView({ block: "center" }); insertInto(t, stamp(), true); }
        else toast("[Welfare114 확장프로그램] 조치사항 칸을 찾지 못했습니다. 문서정보에서 조치사항 칸을 클릭한 후 다시 시도하시기 바랍니다.");
      }, 150);
      return;
    }
    toast("[Welfare114 확장프로그램] 입력할 칸을 찾지 못했습니다. 조치사항 칸을 클릭한 후 다시 시도하시기 바랍니다.");
  }, true);
})();
