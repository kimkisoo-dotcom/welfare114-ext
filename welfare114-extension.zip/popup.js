// 설정은 크롬에 로그인한 구글 계정에 저장되어 다른 PC에서도 동일하게 적용된다.
const DEFAULTS = { fileType: "both", format: "title", dateFmt: "dash", autoOpen: false, custom: [] };
const DATE = { dash: "2026-04-09", ydash: "26-04-09", dot: "2026.04.09", ydot: "26.04.09", md: "04.09(목)" };

// 직접 만들기에 넣을 수 있는 항목과 예시 값
const FIELDS = [
  { k: "docNo", name: "문서번호", ex: "서비스제공-2026-7" },
  { k: "title", name: "제목", ex: "계획서" },
  { k: "date", name: "기안일", ex: null }, // 날짜 표기 형식을 따름
  { k: "dept", name: "부서명", ex: "서비스제공팀" },
  { k: "writer", name: "작성자", ex: "홍길동" },
  { k: "position", name: "직위", ex: "담당" },
  { k: "keep", name: "보존기간", ex: "5년" },
  { k: "open", name: "공개등급", ex: "담당 이상" },
  { k: "category", name: "문서분류", ex: "내부" }
];
const FIELD_NAME = Object.fromEntries(FIELDS.map(f => [f.k, f.name]));
const BAD = /[\\/:*?"<>|]/;
const RULE_NAME = {
  title: "제목", doc: "[문서번호] 제목", docdate: "[문서번호] [기안일] 제목", date: "[기안일] 제목", custom: "직접 만들기"
};

function exampleValue(k, dateFmt) {
  const f = FIELDS.find(x => x.k === k);
  return k === "date" ? DATE[dateFmt] : (f ? f.ex : "");
}

function examples(dateFmt) {
  const d = DATE[dateFmt];
  return {
    title: "계획서",
    doc: "[서비스제공-2026-7] 계획서",
    docdate: `[서비스제공-2026-7] [${d}] 계획서`,
    date: `[${d}] 계획서`
  };
}

// background.js 의 joinParts 와 같은 규칙:
// 기본은 공백. 여는 괄호 뒤·닫는 괄호 앞, 구분 기호(_ - .)만 있는 글자 블록 앞뒤는 붙인다.
const SEP_ONLY = /^[_\-.]+$/;
function joinParts(parts) {
  let out = "";
  let prevSep = false;
  for (const p of parts) {
    if (out && !prevSep && !p.sep && !/[\[({]$/.test(out) && !/^[\])}]/.test(p.v)) out += " ";
    out += p.v;
    prevSep = p.sep;
  }
  return out;
}

function customPreview(blocks, dateFmt) {
  const parts = blocks
    .map(b => ({ v: b.t === "text" ? b.v : exampleValue(b.k, dateFmt), sep: b.t === "text" && SEP_ONLY.test(b.v) }))
    .filter(p => p.v);
  if (!blocks.some(b => b.t === "field" && b.k === "title")) parts.push({ v: "계획서", sep: false });
  return joinParts(parts).replace(/\s+/g, " ").trim() + ".pdf";
}

function customLabel(blocks) {
  if (!blocks.length) return "직접 만들기 (비어 있음)";
  return joinParts(blocks.map(b => ({
    v: b.t === "text" ? b.v : FIELD_NAME[b.k],
    sep: b.t === "text" && SEP_ONLY.test(b.v)
  })));
}

let state = { ...DEFAULTS };

function renderTray() {
  const tray = document.getElementById("tray");
  tray.textContent = "";
  if (!state.custom.length) {
    const e = document.createElement("span");
    e.className = "empty";
    e.textContent = "아래 항목이나 글자를 추가하세요. (제목이 없으면 맨 뒤에 자동으로 붙습니다)";
    tray.appendChild(e);
  }
  state.custom.forEach((b, i) => {
    const el = document.createElement("span");
    el.className = "blk " + (b.t === "text" ? "text" : "field");
    const label = document.createElement("span");
    label.textContent = b.t === "text" ? b.v : FIELD_NAME[b.k];
    const del = document.createElement("button");
    del.className = "del";
    del.textContent = "✕";
    del.title = "삭제";
    del.addEventListener("click", () => {
      const custom = state.custom.filter((_, j) => j !== i);
      save({ custom });
    });
    el.append(label, del);
    tray.appendChild(el);
  });
  document.getElementById("pv").textContent = customPreview(state.custom, state.dateFmt);
}

function render() {
  const s = state;
  document.querySelectorAll("#fileType button").forEach(b => b.classList.toggle("on", b.dataset.v === s.fileType));
  document.querySelectorAll("input[name=format]").forEach(r => (r.checked = r.value === s.format));
  document.getElementById("dateFmt").value = s.dateFmt;
  document.getElementById("autoOpen").checked = !!s.autoOpen;
  const ex = examples(s.dateFmt);
  document.querySelectorAll("[data-ex]").forEach(el => (el.textContent = ex[el.dataset.ex]));
  document.getElementById("custom").classList.toggle("on", s.format === "custom");
  document.getElementById("curRule").textContent = s.format === "custom" ? customLabel(s.custom) : RULE_NAME[s.format];
  renderTray();
}

async function save(patch) {
  state = { ...state, ...patch };
  await chrome.storage.sync.set(patch);
  render();
}

// 항목 버튼
const fieldsBox = document.getElementById("fields");
FIELDS.forEach(f => {
  const b = document.createElement("button");
  b.textContent = f.name;
  b.addEventListener("click", () => save({ custom: [...state.custom, { t: "field", k: f.k }] }));
  fieldsBox.appendChild(b);
});

// 글자 입력: 사용할 수 없는 문자가 있으면 추가 자체를 막는다
const txt = document.getElementById("txt");
const addTxt = document.getElementById("addTxt");
const err = document.getElementById("err");
function checkTxt() {
  const bad = BAD.test(txt.value);
  txt.classList.toggle("bad", bad);
  err.classList.toggle("on", bad);
  addTxt.disabled = bad || !txt.value.trim();
  return !bad;
}
txt.addEventListener("input", checkTxt);
function addText() {
  const v = txt.value.trim();
  if (!v || !checkTxt()) return;
  save({ custom: [...state.custom, { t: "text", v }] });
  txt.value = "";
  checkTxt();
}
addTxt.addEventListener("click", addText);
txt.addEventListener("keydown", e => { if (e.key === "Enter") addText(); });
checkTxt();

// 접기/펼치기 (기본은 접힘)
document.getElementById("foldHd").addEventListener("click", () => document.getElementById("fold").classList.toggle("open"));

(async () => {
  // 예전 버전에서 이 PC에만 저장된 설정이 있으면 함께 반영
  const local = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const synced = await chrome.storage.sync.get(Object.keys(DEFAULTS));
  state = { ...DEFAULTS, ...local, ...synced };
  if (!DATE[state.dateFmt]) state.dateFmt = "dash";
  if (!Array.isArray(state.custom)) state.custom = [];
  render();
})();

document.querySelectorAll("#fileType button").forEach(b =>
  b.addEventListener("click", () => save({ fileType: b.dataset.v })));
document.querySelectorAll("input[name=format]").forEach(r =>
  r.addEventListener("change", () => save({ format: r.value })));
document.getElementById("dateFmt").addEventListener("change", e => save({ dateFmt: e.target.value }));
document.getElementById("autoOpen").addEventListener("change", e => save({ autoOpen: e.target.checked }));
document.getElementById("openRoot").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "openRoot" });
  window.close();
});

// ---------- 조치사항 자동 입력 ----------
const MEMO_DEFAULT_KEY = { alt: true, ctrl: false, shift: false, code: "KeyQ" };
let memo = { memoOn: false, memoName: "", memoFmt: "md_name", memoKey: MEMO_DEFAULT_KEY };

function keyLabel(k) {
  const key = k.code.replace(/^Key/, "").replace(/^Digit/, "");
  return [k.ctrl && "Ctrl", k.alt && "Alt", k.shift && "Shift", key].filter(Boolean).join(" + ");
}

function memoExample(fmt, name) {
  const d = new Date();
  const m = d.getMonth() + 1, day = d.getDate();
  const n = name || "홍길동";
  if (fmt === "name_md") return `${n}(${m}/${day})`;
  if (fmt === "name_dot") return `${n}(${m}.${day}.)`;
  return `${m}/${day} ${n}`;
}

function renderMemo() {
  const nameEl = document.getElementById("memoName");
  if (document.activeElement !== nameEl) nameEl.value = memo.memoName;
  document.querySelectorAll("input[name=memoFmt]").forEach(r => (r.checked = r.value === memo.memoFmt));
  document.querySelectorAll("[data-memo]").forEach(el => (el.textContent = memoExample(el.dataset.memo, memo.memoName)));
  document.getElementById("memoKey").textContent = keyLabel(memo.memoKey);
  document.getElementById("memoOn").checked = memo.memoOn;
  document.getElementById("memoBody").classList.toggle("off", !memo.memoOn);
  document.getElementById("memoCur").textContent = !memo.memoOn ? "사용 안 함"
    : memo.memoName
    ? `${memoExample(memo.memoFmt, memo.memoName)} · ${keyLabel(memo.memoKey)}`
    : `이름을 입력하시기 바랍니다 · ${keyLabel(memo.memoKey)}`;
}

async function saveMemo(patch) {
  memo = { ...memo, ...patch };
  await chrome.storage.sync.set(patch);
  renderMemo();
}

// 크롬·웨일·윈도우 기본 단축키와 겹치지 않는 조합만 허용
const ALT_BLOCK = ["D", "E", "F"];
const CTRL_SHIFT_BLOCK = ["Q", "W", "T", "N", "J", "I", "B", "O", "M", "R", "H", "P", "A", "C", "V", "X", "Z", "Delete"];
function keyAllowed(k) {
  const letter = /^Key[A-Z]$/.test(k.code), digit = /^Digit\d$/.test(k.code), fkey = /^F\d{1,2}$/.test(k.code);
  const ch = k.code.replace(/^Key/, "");
  if (fkey) return !k.alt && !k.ctrl && !k.shift && ["F2", "F4", "F8", "F9"].includes(k.code);
  if (!letter && !digit) return false;
  if (k.alt && !k.ctrl && !k.shift) return !ALT_BLOCK.includes(ch);
  if (k.ctrl && k.shift && !k.alt) return !CTRL_SHIFT_BLOCK.includes(ch);
  return false;
}

let capturing = false;
const keyBtn = document.getElementById("keyBtn");
const keyErr = document.getElementById("keyErr");
const keyBox = document.getElementById("memoKey");
function stopCapture() {
  capturing = false;
  keyBox.classList.remove("wait");
  keyBtn.textContent = "단축키 변경";
  renderMemo();
}
keyBtn.addEventListener("click", () => {
  if (capturing) return stopCapture();
  capturing = true;
  keyErr.classList.remove("on");
  keyBox.classList.add("wait");
  keyBox.textContent = "원하는 키를 누르십시오 (취소: Esc)";
  keyBtn.textContent = "취소";
});
document.addEventListener("keydown", e => {
  if (!capturing) return;
  e.preventDefault();
  if (e.code === "Escape") return stopCapture();
  if (["ControlLeft", "ControlRight", "AltLeft", "AltRight", "ShiftLeft", "ShiftRight", "MetaLeft", "MetaRight"].includes(e.code)) return;
  const k = { alt: e.altKey, ctrl: e.ctrlKey, shift: e.shiftKey, code: e.code };
  if (!keyAllowed(k)) {
    keyErr.textContent = "다른 기능과 겹칠 수 있는 단축키입니다. Alt + 글자(D·E·F 제외), Ctrl + Shift + 글자, F2·F4·F8·F9 중에서 지정하시기 바랍니다.";
    keyErr.classList.add("on");
    return;
  }
  keyErr.classList.remove("on");
  saveMemo({ memoKey: k }).then(stopCapture);
}, true);

let nameTimer = null;
document.getElementById("memoName").addEventListener("input", e => {
  clearTimeout(nameTimer);
  const v = e.target.value.trim();
  nameTimer = setTimeout(() => saveMemo({ memoName: v }), 300);
});
document.querySelectorAll("input[name=memoFmt]").forEach(r =>
  r.addEventListener("change", () => saveMemo({ memoFmt: r.value })));
document.getElementById("memoOn").addEventListener("change", e => saveMemo({ memoOn: e.target.checked }));
document.getElementById("memoHd").addEventListener("click", () => document.getElementById("memoFold").classList.toggle("open"));

chrome.storage.sync.get(["memoOn", "memoName", "memoFmt", "memoKey"]).then(s => {
  memo = {
    memoOn: !!s.memoOn,
    memoName: s.memoName || "",
    memoFmt: s.memoFmt || "md_name",
    memoKey: s.memoKey && s.memoKey.code ? s.memoKey : MEMO_DEFAULT_KEY
  };
  renderMemo();
});

// ---------- 그룹웨어 도메인 ----------
function openSetup(e) { if (e) e.preventDefault(); chrome.tabs.create({ url: "setup.html" }); window.close(); }
document.getElementById("domChange").addEventListener("click", openSetup);
document.getElementById("goSetup").addEventListener("click", openSetup);
chrome.storage.local.get("domain").then(s => {
  document.getElementById("domName").textContent = s.domain || "미등록";
  document.getElementById("noDomain").classList.toggle("on", !s.domain);
});

document.getElementById("ver").textContent = "v" + chrome.runtime.getManifest().version;
