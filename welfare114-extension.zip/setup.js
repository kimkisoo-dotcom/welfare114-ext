// 초기 설정: 그룹웨어 주소 등록 -> 다운로드 보안 설정 안내
const urlEl = document.getElementById("url");
const pv = document.getElementById("pv");
const msg1 = document.getElementById("msg1");
const step2 = document.getElementById("step2");
const done = document.getElementById("done");
let registered = null;

function show(el, text, cls) {
  el.textContent = text;
  el.className = "msg on " + cls;
}

function enableNext(domain) {
  registered = domain;
  step2.classList.remove("off");
  done.disabled = false;
}

// 입력하는 동안 등록될 도메인을 미리 보여준다.
urlEl.addEventListener("input", () => {
  const d = parseDomain(urlEl.value);
  pv.innerHTML = "";
  if (urlEl.value.trim() && d) {
    pv.append("등록될 도메인: ");
    const b = document.createElement("b");
    b.textContent = d;
    pv.append(b);
  }
});

// 크롬 권한 요청은 버튼 클릭 직후에 바로 호출해야 한다.
document.getElementById("reg").addEventListener("click", () => {
  const d = parseDomain(urlEl.value);
  if (!d) {
    show(msg1, "올바른 주소가 아닙니다. 그룹웨어 화면의 주소를 그대로 붙여넣으십시오.", "bad");
    return;
  }
  chrome.permissions.request({ origins: [originPattern(d)] }).then(granted => {
    if (!granted) {
      show(msg1, "접근 권한이 허용되지 않아 등록하지 못했습니다. 다시 시도하신 후 '허용'을 선택하시기 바랍니다.", "bad");
      return;
    }
    chrome.runtime.sendMessage({ type: "setDomain", domain: d }).then(res => {
      if (res && res.ok) {
        show(msg1, `✔ 등록이 완료되었습니다: ${res.domain}`, "ok");
        enableNext(res.domain);
      } else {
        show(msg1, "등록하지 못했습니다. 잠시 후 다시 시도하시기 바랍니다.", "bad");
      }
    });
  });
});
urlEl.addEventListener("keydown", e => { if (e.key === "Enter") document.getElementById("reg").click(); });

// 크롬 사이트 설정 화면을 연다 (확장은 이 설정을 직접 바꿀 수 없음).
document.getElementById("sec").addEventListener("click", () => {
  if (!registered) return;
  const site = encodeURIComponent(`http://www.${registered}:8080`);
  chrome.tabs.create({ url: `chrome://settings/content/siteDetails?site=${site}` });
});

done.addEventListener("click", () => window.close());

// 이미 등록된 도메인이 있으면 표시
chrome.storage.local.get(["domain", "preset"]).then(s => {
  if (!s.domain) return;
  urlEl.value = s.domain;
  urlEl.dispatchEvent(new Event("input"));
  show(msg1, s.preset ? `기관 기본 주소가 등록되어 있습니다: ${s.domain}` : `현재 등록된 도메인: ${s.domain} (변경하려면 새 주소를 입력하고 등록하십시오)`, "ok");
  enableNext(s.domain);
});
